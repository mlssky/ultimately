/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/*
 * DDM-specific internal heap functions.
 */
#ifndef DALVIK_ALLOC_DDMHEAP_H_
#define DALVIK_ALLOC_DDMHEAP_H_

/*
 * Sends the current heap info to the DDM server.
 * Should be called after a GC when gcHeap->ddmHpifWhen
 * is non-zero.
 */
void dvmDdmSendHeapInfo(int reason, bool shouldLock);

/*
 * Walks through the heap and sends a series of
 * HPST/NHST, HPSG/HPSO/NHSG, and HPEN/NHEN chunks that describe
 * the contents of the GC or native heap.
 *
 * @param shouldLock If true, grab the heap lock.  If false,
 *                   the heap lock must already be held.
 * @param heap       If false, dump the GC heap; if true, dump the
 *                   native heap.
 */
void dvmDdmSendHeapSegments(bool shouldLock, bool native);

#endif  // DALVIK_ALLOC_DDMHEAP_H_
