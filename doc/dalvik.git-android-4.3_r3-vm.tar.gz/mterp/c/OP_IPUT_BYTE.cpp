HANDLE_IPUT_X(OP_IPUT_BYTE,             "", Int, )
OP_END
