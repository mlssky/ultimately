HANDLE_SPUT_X(OP_SPUT_SHORT,            "", Int, )
OP_END
