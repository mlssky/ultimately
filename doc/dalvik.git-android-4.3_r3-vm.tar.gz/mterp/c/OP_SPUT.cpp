HANDLE_SPUT_X(OP_SPUT,                  "", Int, )
OP_END
