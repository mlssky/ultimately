HANDLE_UNOP(OP_NOT_INT, "not-int", , ^ 0xffffffff, )
OP_END
