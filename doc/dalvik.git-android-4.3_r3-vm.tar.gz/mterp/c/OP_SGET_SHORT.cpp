HANDLE_SGET_X(OP_SGET_SHORT,            "", Int, )
OP_END
