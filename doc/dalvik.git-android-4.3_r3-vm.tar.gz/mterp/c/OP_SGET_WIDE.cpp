HANDLE_SGET_X(OP_SGET_WIDE,             "-wide", Long, _WIDE)
OP_END
