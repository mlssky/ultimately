HANDLE_IPUT_X(OP_IPUT_CHAR,             "", Int, )
OP_END
