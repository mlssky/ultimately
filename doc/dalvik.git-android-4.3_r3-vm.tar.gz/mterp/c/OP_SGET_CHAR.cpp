HANDLE_SGET_X(OP_SGET_CHAR,             "", Int, )
OP_END
