%include "c/OP_MOVE_RESULT.cpp"
