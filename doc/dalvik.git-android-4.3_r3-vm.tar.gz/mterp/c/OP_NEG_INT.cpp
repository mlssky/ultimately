HANDLE_UNOP(OP_NEG_INT, "neg-int", -, , )
OP_END
