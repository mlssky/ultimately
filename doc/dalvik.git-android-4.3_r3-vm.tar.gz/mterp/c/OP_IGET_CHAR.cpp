HANDLE_IGET_X(OP_IGET_CHAR,             "", Int, )
OP_END
