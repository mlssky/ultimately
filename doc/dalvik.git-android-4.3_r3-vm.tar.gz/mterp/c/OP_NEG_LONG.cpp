HANDLE_UNOP(OP_NEG_LONG, "neg-long", -, , _WIDE)
OP_END
