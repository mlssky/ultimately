HANDLE_SPUT_X(OP_SPUT_CHAR,             "", Int, )
OP_END
