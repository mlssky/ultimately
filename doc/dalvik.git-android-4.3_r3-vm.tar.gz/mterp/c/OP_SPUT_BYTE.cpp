HANDLE_SPUT_X(OP_SPUT_BYTE,             "", Int, )
OP_END
