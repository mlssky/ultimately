HANDLE_IGET_X(OP_IGET_WIDE,             "-wide", Long, _WIDE)
OP_END
