Dalvik interpreter entry point.

The "mterp" directory now holds the interpreter implementation.
