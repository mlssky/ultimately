Original source from Apache Harmony 5.0M15 (r991518 from 2010-09-01) at
http://harmony.apache.org/.

The following files are from drlvm/vm/port/src/encoder/ia32_em64t.

    dec_base.cpp
    dec_base.h
    enc_base.cpp
    enc_base.h
    enc_defs.h
    enc_prvt.h
    enc_tabl.cpp
    encoder.cpp
    encoder.h
    encoder.inl

The following files are derived partially from the original Apache
Harmony files.

    enc_defs_ext.h -- derived from enc_defs.h
    enc_wrapper.h  -- derived from encoder.h





