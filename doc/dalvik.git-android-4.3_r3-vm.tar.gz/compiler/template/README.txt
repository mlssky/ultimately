See README.txt under dalvik/vm/mterp for details.
